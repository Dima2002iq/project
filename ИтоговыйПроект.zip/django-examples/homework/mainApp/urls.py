from django.conf.urls import url, include
from django.views.generic import ListView, DetailView
from mainApp.models import News
from . import views

urlpatterns = [
    url(
        r'^$',
        ListView.as_view(queryset = News.objects.all().order_by("-date"),
        template_name="mainApp/news.html")
    ),
    url(
        r'^news/(?P<pk>\d+)$',
        DetailView.as_view(model = News, template_name = "mainApp/post.html")
    ),
    url(r'^contacts/$', views.contacts, name='contacts'),
    url(r'^about-us/$', views.about, name='about'),
]
