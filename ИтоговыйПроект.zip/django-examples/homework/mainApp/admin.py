from django.contrib import admin
from mainApp.models import News

admin.site.register(News)
